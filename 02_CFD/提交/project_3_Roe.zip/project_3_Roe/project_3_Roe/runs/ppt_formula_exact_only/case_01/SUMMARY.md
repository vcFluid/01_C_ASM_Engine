# Roe FVM Summary

- completed: 1
- unstable/failed: 0

- best rho L1: 5.896688e-03 (CFL=0.5, Nx=501)
- best u L1: 7.402396e-03 (CFL=0.5, Nx=501)
- best p L1: 4.441242e-03 (CFL=0.5, Nx=501)
