# Roe FVM Summary

- completed: 1
- unstable/failed: 0

- best rho L1: 6.002112e-03 (CFL=0.5, Nx=501)
- best u L1: 3.788334e-03 (CFL=0.5, Nx=501)
- best p L1: 4.172370e-03 (CFL=0.5, Nx=501)
