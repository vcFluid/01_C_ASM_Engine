# Roe FVM Summary

- completed: 1
- unstable/failed: 0

- best rho L1: 7.374577e-03 (CFL=0.5, Nx=501)
- best u L1: 2.421924e-02 (CFL=0.5, Nx=501)
- best p L1: 2.451568e-02 (CFL=0.5, Nx=501)
