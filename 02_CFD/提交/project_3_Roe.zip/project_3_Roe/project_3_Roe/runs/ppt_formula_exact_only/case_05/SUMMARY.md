# Roe FVM Summary

- completed: 1
- unstable/failed: 0

- best rho L1: 5.805838e-03 (CFL=0.5, Nx=501)
- best u L1: 6.325973e-03 (CFL=0.5, Nx=501)
- best p L1: 3.516416e-03 (CFL=0.5, Nx=501)
