# Roe FVM Summary

- completed: 1
- unstable/failed: 0

- best rho L1: 1.827926e-02 (CFL=0.5, Nx=501)
- best u L1: 1.321077e-02 (CFL=0.5, Nx=501)
- best p L1: 1.575401e-02 (CFL=0.5, Nx=501)
