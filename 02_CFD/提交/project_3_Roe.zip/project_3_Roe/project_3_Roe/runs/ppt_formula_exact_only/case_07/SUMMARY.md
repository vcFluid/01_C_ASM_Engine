# Roe FVM Summary

- completed: 1
- unstable/failed: 0

- best rho L1: 1.261435e-01 (CFL=0.5, Nx=501)
- best u L1: 6.149989e-10 (CFL=0.5, Nx=501)
- best p L1: 3.010038e-09 (CFL=0.5, Nx=501)
